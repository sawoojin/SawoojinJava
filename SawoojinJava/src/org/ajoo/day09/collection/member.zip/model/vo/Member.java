package org.ajoo.day09.collection.member.model.vo;

public class Member {
	private String memberId;
	private int memberPw;
	private String memberName;
	private String memberEmail;
	private int memberPhone;
	
	public Member() {}
	
	public Member(String memberId, int memberPw, String memberName, String memberEmail, int memberPhone) {
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.memberName = memberName;
		this.memberEmail = memberEmail;
		this.memberPhone = memberPhone;
	}
}
