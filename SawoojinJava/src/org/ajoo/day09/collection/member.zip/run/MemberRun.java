package org.ajoo.day09.collection.member.run;

import org.ajoo.day09.collection.member.view.MemberView;

public class MemberRun {
	public static void main(String[] args) {
		MemberView view = new MemberView();
		view.printMenu();
	}
}